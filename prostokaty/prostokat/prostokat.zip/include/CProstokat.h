#ifndef CPROSTOKAT_H
#define CPROSTOKAT_H
struct TPunkt{
    int X;
    int Y;
};

class CProstokat
{
    public:
        CProstokat();
        ~CProstokat();

        void Obrot();
        void Rysuj();
        void Oblicz();
    static bool horyzontalnie,vertykalnie,normalnie,kolorZmiana;
    private:
        int X,Y;
        int kolor;
        double Angle,dAngle,przekatna;
        int dX,dY,dOdstepX,dOdstepY;
        int odstepX,odstepY,domyslnyOdstepX,domyslnyOdstepY;
        TPunkt pkty[4];

        void ObliczPunkty();
        void Ruch();
        void RuchHoryzontalny();
        void RuchVertykalny();
        void ObrocPunkty();
        void RysujPunkty();
        void Zmienkolor();
};

#endif // CPROSTOKAT_H
