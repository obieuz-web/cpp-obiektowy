#include "../include/CProstokatPudelko.h"
#include <iostream>
CProstokatPudelko::CProstokatPudelko()
{
    //ctor
}

CProstokatPudelko& CProstokatPudelko::operator++(int){

    prostokaty.push_back(std::make_shared<CProstokat>());

    return *this;
}

CProstokatPudelko& CProstokatPudelko::operator--(int){

    if(!prostokaty.empty()){
        prostokaty.erase(prostokaty.begin());
    }else{
        std::cout<<"Nie ma prostokatow :("<<std::endl;
    }

    return *this;
}

void CProstokatPudelko::RuchProstokatow(){

    for(int i=0;i<prostokaty.size();++i){
        prostokaty[i]->Oblicz();
    }
}

CProstokatPudelko::~CProstokatPudelko()
{
    std::cout<<"Zamknito okno";
}
